$(document).ready(function() {
 
    setTimeout(function(){
        $('.preloader').fadeOut('slow');
    }, 3000);
 
});